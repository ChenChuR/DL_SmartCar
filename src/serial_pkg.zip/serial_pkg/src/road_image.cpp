#include "ros/ros.h"
#include "opencv2/opencv.hpp"
#include "image_transport/image_transport.h"
#include "cv_bridge/cv_bridge.h"
#include "iostream"
#include "serial_pkg/speed.h"

#include "std_msgs/String.h"

#include "std_msgs/Int16.h"

#include <string>
#include "sensor_msgs/Image.h"
#include "image_transport/image_transport.h"
#include "opencv2/imgproc/types_c.h"
#include "opencv2/imgproc.hpp"
#include <vector>

enum PID_MODE
{
    PID_POSITION = 0,//位置式PID
    PID_DELTA        //增量式PID
};

typedef struct
{
    uint8_t mode;
    //PID 参数
    float Kp;
    float Ki;
    float Kd;

    float max_out;  //最大输出
    float max_iout; //最大积分输出

    float set;      //设定值
    float fdb;      //实际值

    float out;
    float Pout;
    float Iout;
    float Dout;
    float Dbuf[3];  //微分项 0最新 1上一次 2上上次
    float error[3]; //误差项 0最新 1上一次 2上上次

} PidTypeDef;


void LimitMax(float *input,float *max)   
{                          
    if (*input > *max)
    {
        *input = *max;
    }
    else if (*input < -*max)
        *input = -*max;
}

void PID_Init(PidTypeDef *pid, uint8_t mode, const float PID[3], float max_out, float max_iout)
{
    if (pid == NULL || PID == NULL)
    {
        return;
    }
    pid->mode = mode;
    pid->Kp = PID[0];
    pid->Ki = PID[1];
    pid->Kd = PID[2];
    pid->max_out = max_out;
    pid->max_iout = max_iout;
    pid->Dbuf[0] = pid->Dbuf[1] = pid->Dbuf[2] = 0.0f;
    pid->error[0] = pid->error[1] = pid->error[2] = pid->Pout = pid->Iout = pid->Dout = pid->out = 0.0f;
}

float PID_Calc(PidTypeDef *pid, float ref, float set)
{
    if (pid == NULL)
    {
        return 0.0f;
    }
    pid->error[2] = pid->error[1];
    pid->error[1] = pid->error[0];
    pid->set = set;
    pid->fdb = ref;
    pid->error[0] = set - ref;
    if (pid->mode == PID_POSITION)
    {
        pid->Pout = pid->Kp * pid->error[0];
        pid->Iout += pid->Ki * pid->error[0];
        pid->Dbuf[2] = pid->Dbuf[1];
        pid->Dbuf[1] = pid->Dbuf[0];
        pid->Dbuf[0] = (pid->error[0] - pid->error[1]);
        pid->Dout = pid->Kd * pid->Dbuf[0];
        LimitMax(&pid->Iout, &pid->max_iout);
        pid->out = pid->Pout + pid->Iout + pid->Dout;
        LimitMax(&pid->out, &pid->max_out);
    }
    else if (pid->mode == PID_DELTA)
    {
        pid->Pout = pid->Kp * (pid->error[0] - pid->error[1]);
        pid->Iout = pid->Ki * pid->error[0];
        pid->Dbuf[2] = pid->Dbuf[1];
        pid->Dbuf[1] = pid->Dbuf[0];
        pid->Dbuf[0] = (pid->error[0] - 2.0f * pid->error[1] + pid->error[2]);
        pid->Dout = pid->Kd * pid->Dbuf[0];
        pid->out += pid->Pout + pid->Iout + pid->Dout;
        LimitMax(&pid->out, &pid->max_out);
    }
    return pid->out;
}

void PID_clear(PidTypeDef *pid)
{
    if (pid == NULL)
    {
        return;
    }

    pid->error[0] = pid->error[1] = pid->error[2] = 0.0f;
    pid->Dbuf[0] = pid->Dbuf[1] = pid->Dbuf[2] = 0.0f;
    pid->out = pid->Pout = pid->Iout = pid->Dout = 0.0f;
    pid->fdb = pid->set = 0.0f;
}

//light detection main function
int lightDetection(cv::Mat image);
using namespace std;

// lightDetection function
int processImgR(cv::Mat);
int processImgG(cv::Mat);
bool isIntersected(cv::Rect, cv::Rect);
void red(cv::Mat image, std_msgs::String *line, std_msgs::String *light);

// lightDetection global variables
bool isFirstDetectedR = true;
bool isFirstDetectedG = true;
cv::Rect* lastTrackBoxR;
cv::Rect* lastTrackBoxG;
int lastTrackNumR;
int lastTrackNumG;
int maxNum;

bool turnLeft = false;

PidTypeDef angle_pid;
const float angle_PID[3] = {1,0,0.5};
float angle_max_out = 100;
float angle_max_iout = 0;
float temp = 0;

void doMsg(const std_msgs::Int16::ConstPtr& msgs)
{
    int16_t temp = msgs->data;
    if (temp == 2)
    {
        cout << "test" << endl;
        cv::Mat img = cv::imread("/home/win/catkin_ws/src/serial_pkg/photo/pic.jpg");
       cv::imwrite("/home/win/catkin_ws/src/serial_pkg/photo/test.jpg",img); 
    }
}

cv::Point FitPoint(cv::Mat Coe,int n,int x)
{
	int i;
	double y = 0;
	for (i = n; i >= 0; i--)
	{
		y += std::pow(x, i) * (Coe.at<double>(i, 0));
	}
	return cv::Point(y,x);
}

/**
  * @brief 最小二乘法拟合中线
  * @param point 待拟合的点集
  * @param n 拟合次数
  * @param Coe 多项式系数矩阵
  * @return void
  */
void FitPolynomialCurve(const std::vector<cv::Point>& points, int n, cv::Mat& Coe) 
{
	//最小二乘法多项式曲线拟合原理与实现 
	int N = points.size();
	cv::Mat X = cv::Mat::zeros(n + 1, n + 1, CV_64FC1);
	for (int i = 0; i < n + 1; i++) {
		for (int j = 0; j < n + 1; j++) {
			for (int k = 0; k < N; k++) {
				X.at<double>(i, j) = X.at<double>(i, j) +
					std::pow(points[k].x, i + j);
			}
		}
	}
	cv::Mat Y = cv::Mat::zeros(n + 1, 1, CV_64FC1);
	for (int i = 0; i < n + 1; i++) {
		for (int k = 0; k < N; k++) {
			Y.at<double>(i, 0) = Y.at<double>(i, 0) +
				std::pow(points[k].x, i) * points[k].y;
		}
	}
	Coe = cv::Mat::zeros(n + 1, 1, CV_64FC1);
	cv::solve(X, Y, Coe, cv::DECOMP_LU);
}

/**
  * @brief 处理图像，获得中线斜率
  * @param  frame 待处理的图像
  * @return 角度
  */
int sta = 0;
uint16_t image_process(cv::Mat *frame)
{
    cv::Mat frameBGR, hsv, mask, kernel, way;
	cv::Mat LeftCoe,RightCoe;

	std::vector<cv::Point> left, right, mid;
	cv::Rect rect(0,180,640,300);

	int i, j1, j2;
	int TurnSign;
	float offset = 0;
	int col = 640, row = 480;
	int Cmid = col / 2;

	cv::resize(*frame, frameBGR, cv::Size(col, row));
	//frameBGR(rect).copyTo(frameBGR);
	//cv::imshow("原图", frame);
	cv::GaussianBlur(frameBGR, frameBGR, cv::Size(7, 7), 0);
	cv::cvtColor(frameBGR, hsv, CV_BGR2HSV);
	cv::inRange(hsv, cv::Scalar(26, 43, 83), cv::Scalar(90, 255, 255), mask);
	kernel = cv::getStructuringElement(cv::MORPH_ELLIPSE, cv::Size(7, 7));
	cv::morphologyEx(mask, mask, cv::MORPH_CLOSE, kernel);
	cv::morphologyEx(mask, mask, cv::MORPH_OPEN, kernel);
	//imshow("t",mask);
	//*frame = mask;
	ros::param::get("turn_left",turnLeft);
	if(turnLeft)
	{
		
		if(mask.at<uchar>(0, Cmid) == 255)
		{
			sta = 8;
			turnLeft = false;
		}
		
	}
	if(sta > 0)
	{
		sta--;
		return 620;
	}
	//Point(col,row)
	//at<>(row/x,col/y)
	for (i = row-1; i >= 0; i--) //从下到上
	{
		if (mask.at<uchar>(i, Cmid) == 255)
		{
			if (left.empty() && !right.empty())
			{
				std::cout << "left" << std::endl;
				return 500;
			}
			else if (!left.empty() && right.empty())
			{
				std::cout << "right" << std::endl;
				return 1000;
			}
			continue;
		}
		for (j1 = Cmid; j1 > 0; j1--) //从中间向左
		{
			if (mask.at<uchar>(i, j1) == 0 && mask.at<uchar>(i, j1 - 1) == 255)
			{
				left.push_back(cv::Point(i,j1 - 1));
				break;
			}
		}
		for (j2 = Cmid; j2 < col - 1; j2++) //从中间向右
		{
			if (mask.at<uchar>(i, j2) == 0 && mask.at<uchar>(i, j2 + 1) == 255)
			{
				right.push_back(cv::Point(i,j2 + 1));
				break;
			}
		}
	}
    if(left.empty() && right.empty())
    {
        return -100;
    }
	FitPolynomialCurve(left, 1, LeftCoe);
	FitPolynomialCurve(right, 1, RightCoe);

	for (i = row - 1; i >= 0; i--)
	{
		mid.push_back((FitPoint(LeftCoe, 1, i)+ FitPoint(RightCoe, 1, i))/2);
		offset += mid.back().x - Cmid;
		cv::circle(mask, mid.back(), 5, cv::Scalar(255, 255, 255), -1);
	}
	//负偏右，正偏左
	offset /= row;
	//std::cout << offset << std::endl;
	//std::cout << offset << std::endl;
	temp = offset;
	std::cout<< "___________" << temp << "____________" << std::endl;
	int offeset_temp = 135;
	if(temp > -offeset_temp && temp < offeset_temp)
	{
		uint16_t wz_pwm = PID_Calc(&angle_pid,temp,0);
		ROS_INFO("%f %f",745-angle_pid.out,temp);	
    		return (745-angle_pid.out);
	}
	else if(temp <= -offeset_temp)
	{
		ROS_INFO("LEFT");
		return 500;
	}
	else 
	{
		ROS_INFO("RIGHTT");
		return 1000;
	}

	//TurnSign = 25;

    //if(offset < -TurnSign)
   // {
    //    return -12;
   // }
   // else if(offset > TurnSign)
   // {
  //      return 12;
  //  }
  ////  else
   // {
   //     return 2;
  //  }
}



/**
  * @brief 处理图像，封装速度信息
  * @param  raw_frame 图像指针
  * @param speed 速度信息结构体指针
  * @return void
  */
void Get_Speed(cv::Mat *raw_frame,serial_pkg::speed *speed)
{
    //f dir_th = 0.25;
    uint16_t an = 745;
    //int lightSign = lightDetection(*raw_frame);
    //cout << lightSign << endl;
    an = image_process(raw_frame);
    if(an > 1000)
	an = 1000;
    else if(an < 560)
	an = 560;
    speed->vx = 0;
    speed->angle = 745;

    if(an != -100)
    {
        speed->vx = 0.4;
	if(an >= 600 && an <= 900)
	{
		/*
		if(an > 745)
		{
			speed->vx = 0.4 + (an - 745) * 0.004;
		}
		else
		{
			speed->vx = 0.4 + (745 - an) * 0.004;
		}
		*/
		//speed->vx = 0.6;
	}
        speed->angle =an;
    }
    else
    {
	    speed->vx = 0;
	    speed->angle = 745;
    }
    ROS_INFO("angle:%d %d %f",speed->angle,an,angle_pid.fdb);
}

int main(int argc,char **argv)
{
    ros::init(argc,argv,"speed_pub");
    ros::NodeHandle nh;
    image_transport::ImageTransport it(nh);
    image_transport::Publisher pub = it.advertise("camera/road_image", 5);
    cv::VideoCapture cap;
    cv::Mat frame;
    ros::Publisher speed_pub = nh.advertise<serial_pkg::speed>("speed_msg",1000);
    ROS_INFO("2");

    serial_pkg::speed speed_msg;
    //开启摄像头
    int device_ID = 0;
    if(argc > 1)
        device_ID = argv[1][0] - '0';
    int api_ID = cv::CAP_ANY;
    cap.open(device_ID + api_ID);
    if(!cap.isOpened())
    {
        ROS_ERROR("ERROR! Unable to open camera");
	    return -1;
    }
    ros::Rate loop_rate(200);
    cap.read(frame);
    cv::imwrite("/home/win/catkin_ws/src/serial_pkg/photo/test.jpg",frame);
    PID_Init(&angle_pid,PID_POSITION,angle_PID,angle_max_out,angle_max_iout);
    while(ros::ok())
    {
        cap.read(frame);
	    //cv::imwrite("/home/win/catkin_ws/src/serial_pkg/photo/pic.jpg",frame);
        //ros::Subscriber sub = nh.subscribe<std_msgs::Int16>("pic_msg", 10, doMsg);    
        if(!frame.empty())
        {
            Get_Speed(&frame,&speed_msg);
            sensor_msgs::ImagePtr msg = cv_bridge::CvImage(std_msgs::Header(), "bgr8", frame).toImageMsg();
            pub.publish(msg);
            speed_pub.publish(speed_msg);
        }
        loop_rate.sleep();
        ros::spinOnce();
    }
    return 0;
}
