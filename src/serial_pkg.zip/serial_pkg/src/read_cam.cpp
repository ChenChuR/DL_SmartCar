#include "ros/ros.h"
#include "opencv2/opencv.hpp"
#include "image_transport/image_transport.h"
#include "cv_bridge/cv_bridge.h"
#include "iostream"


int main(int argc, char** argv)
{
        ros::init(argc, argv, "readCam");

        ros::NodeHandle nh;

        image_transport::ImageTransport it(nh);

        image_transport::Publisher pub = it.advertise("camera", 1);

        cv::VideoCapture cap;
        cv::Mat frame;

        int device_ID = 0;
        if(argc > 1)
                device_ID = argv[1][0] - '0';
        int api_ID = cv::CAP_ANY;
        cap.open(device_ID + api_ID);
        if(!cap.isOpened())
        {
                ROS_ERROR("ERROR! Unable to open camera");
	        return -1;
        }
        ros::Rate loop_rate(200);

        while(ros::ok())
        {
                cap.read(frame);

                if(!frame.empty())
                {
                        sensor_msgs::ImagePtr msg = cv_bridge::CvImage(std_msgs::Header(), "bgr8", frame).toImageMsg();
                        pub.publish(msg);
                }
                loop_rate.sleep();
        }
        return 0;
}