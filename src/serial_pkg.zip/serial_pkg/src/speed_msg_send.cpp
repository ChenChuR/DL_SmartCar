#include "ros/ros.h"
#include "serial/serial.h"
#include "serial_pkg/speed.h"
#include "std_msgs/String.h"
#include "std_msgs/Int8.h"
#include "chrono"

#define Start_Byte 0xA5
#define End_Byte 0x5A

serial::Serial ser;
//发送数据缓冲区
unsigned char send_buff[9];

int8_t state = 0;//记录状态
int8_t lightnum = 0;//记录红绿灯
//int8_t linenum = 0;
int leftturn = 0;
ros::Time old1;
ros::Time old2;
ros::Time old3;
ros::Time new1;
ros::Time new2;
ros::Time new3;
ros::Duration elapsed_time1 = ros::Duration(0,0);
ros::Duration elapsed_time2 = ros::Duration(0,0);
int limit = 0;
int leftWait = 0;
int greenwait = 0;

typedef union
{
        float float_data;
        unsigned char byte_data[4];
}Float_Byte;

struct
{
        Float_Byte vx;
        Float_Byte vx_last;
        uint16_t turn_pwm;
        uint16_t last_turn_pwm;
}speed_structure;

unsigned char signageLast;
unsigned char signage;
int on = 0;
int off = 0;
int onCounts;
int offCounts;

/**
 * @brief 封装帧头帧尾，计算校验位，并发送数据
*/
bool Serial_Send(void)
{
        unsigned char sum = 0x00;
        
        send_buff[1] = speed_structure.vx.byte_data[0];
        send_buff[2] = speed_structure.vx.byte_data[1];
        send_buff[3] = speed_structure.vx.byte_data[2];
        send_buff[4] = speed_structure.vx.byte_data[3];

        send_buff[5] = ((speed_structure.turn_pwm & 0xFF00) >> 8);
        send_buff[6] = speed_structure.turn_pwm & 0x00FF;

        for(short i=1;i<7;i++)
                sum += send_buff[i];
        send_buff[7] = sum;
        for(short i=0;i<9;i++);
                //ROS_INFO("%x",send_buff[i]);
        ser.write(send_buff,9);
}
/**
 * @brief 将两个摄像头发送的数据进行处理，获取最终速度信息
 * @param speed_ptr 速度信息指针
*/
void Deal_Msg(const serial_pkg::speed::ConstPtr& speed_ptr)
{
	signage =  speed_ptr->signage;
	//ROS_INFO("%x     ,    %d",signage,state);
	if(signage == 0x00)
	{
                //onCounts ++;
                //if(onCounts > 5)
                //{
                //        on = 1;
                //        state = 3;
                //}
                //if(offCounts > 5)
                //{
                //        on = 0;
                //        state = 4;
                //}

		speed_structure.vx.float_data = speed_ptr->vx;
		speed_structure.turn_pwm = speed_ptr->angle;
		speed_structure.vx_last.float_data = speed_structure.vx.float_data;
		speed_structure.last_turn_pwm = speed_structure.turn_pwm;
	}
	else
	{
                //if(signage == 0x84 && state == 2)
                //{        
                        //onCounts --;
                //}
                //if(signage == 0x88 && state == 3)
                //{
                //        //offCounts --;
                //}
		speed_structure.vx.float_data = speed_structure.vx_last.float_data;
		speed_structure.turn_pwm = speed_structure.last_turn_pwm;
	}
	//ROS_INFO("%d %d\n",speed_structure.turn_pwm,speed_ptr->angle);
	//vx.float_data = speed_ptr->vx;
	//angle.float_data = speed_ptr->angle;
	/*
        if(signage & 0x80)
        {
		//ROS_INFO("%x",signage);
                if((signage == 0x81) && state == 0)
                {
                        vx.float_data  = 0;
                        angle.float_data = 0;
			state = 1;
			return;
                }

        }
	*/
        //if(signage == 0x81)
        //{
         //        vx.float_data = 0;
         //      angle.float_data = 0;
        //}
}

/**
 *@brief 获取红绿灯信息，判断是否左拐
 *@param 红绿灯识别结果
*/
void Deal_light(const std_msgs::String::ConstPtr& msg_p)
{
	if(strcmp(msg_p->data.c_str(),"red_light") == 0)
	{
		lightnum = 2;
	}
	else if(strcmp(msg_p->data.c_str(),"yellow_light") == 0)
	{
		lightnum = 3;
	}
	else if(strcmp(msg_p->data.c_str(),"green_light") == 0)
	{
		lightnum = 1;
	}
	else
	{
		lightnum = 0;
	}
	ROS_INFO("light_detect : %d", lightnum);
	//if(strcmp(msg_p->data.c_str(),"green_light") == 0)
	
}

//void Deal_line(const std_msgs::String::ConstPtr& msg_L)
//{
//        if(msg_L->data == "in_line")
//        {
//                linenum = 1;
//        }
//        else
//        {
//                linenum = 0;
//        }
//	//ROS_INFO("lineNum : %d", linenum);
//}

int main(int argc,char **argv)
{
        ros::init(argc,argv,"serial_send_msg");
        ros::NodeHandle nh;
        ros::Subscriber sub = nh.subscribe<serial_pkg::speed>("speed_msg",1000,Deal_Msg);
	ros::Subscriber subLight = nh.subscribe<std_msgs::String>("light_detect",100,Deal_light);
        //ros::Subscriber subLine = nh.subscribe<std_msgs::String>("line_detect",100,Deal_line);

        //打开串口
        try
        {
                ser.setPort("/dev/ttyUSB0");
                ser.setBaudrate(115200);
                serial::Timeout to = serial::Timeout::simpleTimeout(1000);
                ser.setTimeout(to);
                ser.open();
        }
        catch(serial::IOException &e)
        {
                ROS_ERROR_STREAM("Unable to open port ");
                return -1;
        }
        if(ser.isOpen())
                ROS_INFO_STREAM("Serial Port initialized");
        else
                return -1;

        send_buff[0] = Start_Byte;
        send_buff[8] = End_Byte;
        speed_structure.vx.float_data = 0;
        speed_structure.turn_pwm = 745;
	static bool left_turn_flag = false;
        ros::Rate loop_rate(200);
	ros::param::set("turn_left",false);
        while(ros::ok())
        {
                //Serial_Send();
                //ros::spinOnce();
                //loop_rate.sleep();
		if(signage != 0)
		{
			ROS_INFO("%x",signage);
		}
		//ROS_INFO("%x",signage);
		if(left_turn_flag == true && signage == 0x90)
			signage = 0x00;
		switch(signage)
		{
			case 0x81:
                        {
				if(state == 0)
				{
					ROS_INFO("sidewalk wait");
					speed_structure.vx.float_data = 0;
					Serial_Send();
					ros::Duration(1).sleep();
                                        old1 = ros::Time::now();
					state = 1;
				}
				break;
                        }
                        case 0x82:
                        {
                                //new1 = ros::Time::now();
                                //ros::Duration elapsed_time1 = new1 - old1;
                                //float times1 = elapsed_time1.toSec();
                                 //if(state == 1 && linenum == 1)
                                 //if(state == 1 && times1 > 2.5)
                                 //{
					//ROS_INFO("lamp wait");
                                        //speed_structure.vx.float_data = 0;
                                        //Serial_Send();
                                        //ros::Duration(1).sleep();
                                        //state = 2;
                                 //}
				if(state == 1)
				{
					ROS_INFO("ramp wait");
					speed_structure.vx.float_data = 0;
					Serial_Send();
					ros::Duration(1).sleep();
					state = 2;
				}
                                break;
                        }
                        case 0x84:
                        {
                                //if(on == 0)
                                //{
                                //        on = 1;
                                //        old2 = ros::Time::now();
                                //}
                                //new2 = ros::Time::now();
                                //ros::Duration elapsed_time2 = new2 - old2;
                                //float times2 = elapsed_time2.toSec();
                                //if(state == 2 && times2 > 1)
                                //{
                                //        old3 = ros::Time::now();
                                //        speed_structure.vx.float_data = 0.4;
                                //        limit = 1;
                                //        Serial_Send();
                                //        state = 3;
                                //}
                                        //onCounts = 1;
				if(state == 2)
				{
					speed_structure.vx.float_data = 0.4;
					limit = 1;
					speed_structure.turn_pwm = 745;
					Serial_Send();
					state = 3;
				}
                                break;
                        }
			case 0x88:
                        {
                                //new3 = ros::Time::now();
                                //ros::Duration elapsed_time3 = new3 - old3;
                                //float times3 = elapsed_time3.toSec();
                                //if(state == 3 && times3 > 4.5)
                                //{
                                //        limit = 0;
                                //        Serial_Send();
                                //        state = 4;
                                //}
                                        //offCounts = 1;
				if(state == 3)
				{
					limit = 0;
					//ros::Duration(1).sleep();
					//speed_structure.turn_pwm = 560;
					Serial_Send();
					//ros::Duration(3).sleep();
					//speed_structure.turn_pwm = 960;
					//Serial_Send();
					//ros::Duration(3).sleep();
					state = 4;
				}
				break;
                        }
                        case 0x90:
                                if(state == 4)
                                {
					left_turn_flag = true;
                                        leftturn = 1;
					ROS_INFO("left_turn detect");
					if(leftWait == 0)
					{
						ROS_INFO("left-turn wait");
						speed_structure.vx.float_data = 0;
						Serial_Send();
						leftWait = 1;
						greenwait = 1;
					}
					/*
					else
					{
						if(lightnum != 1)
                                        	{
							//ROS_INFO("no green");
                                                	speed_structure.vx.float_data  = 0;
                                                	Serial_Send();
                                        	}
                                        	else
                                        	{
							//ROS_INFO("green");
                                                	Serial_Send();
							ros::param::set("turn_left",true);
                                        	}
					}
					*/
                                }
                                break;
			default:
                                if(limit == 1)
                                        speed_structure.vx.float_data = 0.4;
				if(greenwait == 1)
				{
					//bool lightDetect = false;
					//ros::param::get("lightDetect", lightDetect);
					//static ros::Time start = ros::Time::now();
				//	static int start_time = ros::Time::now().toSec();
				//	static bool time_flag = true;
					//static ros::Time now = ros::Time::now();
					if(lightnum != 1)
					{
						speed_structure.vx.float_data = 0;
				//		Serial_Send();
						//start_time = ros::Time::now().toSec();
						//ROS_INFO("lightnum != 1");
				//		break;
					}
					else
					{
						left_turn_flag = true;
						greenwait = 0;
						ros::param::set("turn_left",true);
				//		if(time_flag == true)
				//		{
				//			start_time = ros::Time::now().toSec();
				//			time_flag = false;
				//			left_turn_flag = true;
				//		}
				//		Serial_Send();
						/*
						int now_time = ros::Time::now().toSec();
						int time = now_time - start_time;
						ROS_INFO("time :%d",time);
						if(time > 1 && time < 5)
						{
							ROS_INFO("1");
							speed_structure.turn_pwm = 560;
							Serial_Send();
						}
						if(time > 5 && time < 9)
						{
							ROS_INFO("2");
							speed_structure.vx.float_data = 0.8;
							speed_structure.turn_pwm = 745;
							Serial_Send();
						}
						if(time > 9)
						{
							ROS_INFO("3");
							speed_structure.vx.float_data = 0;
							Serial_Send();
						}
						*/
						//ros::Duration(1).sleep();
						//greenwait = 0;
					//	break;
					}

				}
                                if(leftturn == 1 && (speed_structure.turn_pwm == 560 || speed_structure.turn_pwm == 1000))
				{
					ROS_INFO("left turn");
					speed_structure.turn_pwm = 500;
				}
				if(state == 0)
				{
					if(speed_structure.turn_pwm > 800)
					{
						speed_structure.turn_pwm = 800;
					}
				}
				/*
				else if(state == 2)
				{
					if(speed_structure.turn_pwm < 700)
					{
						speed_structure.turn_pwm = 700;
					}
				}
				*/
				Serial_Send();
				break;
		}
		//ROS_INFO("%d",signage);
		ros::spinOnce();
		loop_rate.sleep();
        }
        return 0;
}
